import { MongoClient } from 'mongodb';
import dotenv from 'dotenv';

dotenv.config();

const uri = process.env.MONGODB_URI;
if (!uri) {
  console.error('MONGODB_URI is required in .env file');
  process.exit(1);
}

const client = new MongoClient(uri);
let db;

export const initDB = async () => {
  try {
    await client.connect();
    db = client.db('telegram_bot');
    console.log('Connected to MongoDB');

    // Create indexes
    await db.collection('users').createIndex({ userId: 1 }, { unique: true });
    await db.collection('referrals').createIndex({ referrerId: 1, referredId: 1 }, { unique: true });
    await db.collection('tasks').createIndex({ userId: 1, taskId: 1 }, { unique: true });
    
    return true;
  } catch (error) {
    console.error('MongoDB connection error:', error);
    throw error;
  }
};

export const getUser = async (userId) => {
  try {
    return await db.collection('users').findOne({ userId });
  } catch (error) {
    console.error('Error getting user:', error);
    throw error;
  }
};

export const createUser = async (userId, username) => {
  try {
    const user = {
      userId,
      username,
      points: 1000, // Welcome bonus
      referralCount: 0,
      createdAt: new Date()
    };
    await db.collection('users').insertOne(user);
    return user;
  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  }
};

export const updateUserPoints = async (userId, points) => {
  try {
    await db.collection('users').updateOne(
      { userId },
      { $inc: { points } }
    );
  } catch (error) {
    console.error('Error updating user points:', error);
    throw error;
  }
};

export const addReferral = async (referrerId, referredId) => {
  try {
    await db.collection('referrals').insertOne({
      referrerId,
      referredId,
      status: 'pending',
      createdAt: new Date()
    });
    
    await db.collection('users').updateOne(
      { userId: referrerId },
      { $inc: { referralCount: 1 } }
    );
  } catch (error) {
    console.error('Error adding referral:', error);
    throw error;
  }
};

export const getReferrals = async (userId) => {
  try {
    return await db.collection('referrals')
      .find({ referrerId: userId, status: 'completed' })
      .toArray();
  } catch (error) {
    console.error('Error getting referrals:', error);
    throw error;
  }
};

export const completeTask = async (userId, taskId) => {
  try {
    const task = await db.collection('tasks').findOne({ userId, taskId });
    if (!task) {
      await db.collection('tasks').insertOne({
        userId,
        taskId,
        completed: true,
        pointsAwarded: 100,
        completedAt: new Date()
      });
      await updateUserPoints(userId, 100);
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error completing task:', error);
    throw error;
  }
};