import { getUser, createUser, updateUserPoints, getReferrals, completeTask, addReferral } from '../database/db.js';

const EMOJIS = {
  WELCOME: '👋',
  POINTS: '💎',
  REFERRAL: '🔗',
  TASKS: '✅',
  HELP: 'ℹ️',
  BONUS: '🎁',
  SUCCESS: '✨',
  CHART: '📊'
};

const getMainMenuKeyboard = () => ({
  reply_markup: {
    inline_keyboard: [
      [
        { text: `${EMOJIS.POINTS} Check Points`, callback_data: 'points' },
        { text: `${EMOJIS.REFERRAL} My Referral`, callback_data: 'referral' }
      ],
      [
        { text: `${EMOJIS.TASKS} Available Tasks`, callback_data: 'tasks' },
        { text: `${EMOJIS.CHART} My Stats`, callback_data: 'stats' }
      ]
    ]
  }
});

export const handleStart = async (bot, msg, startParam) => {
  const chatId = msg.chat.id;
  const user = msg.from;
  
  try {
    let dbUser = await getUser(user.id);
    
    if (!dbUser) {
      dbUser = await createUser(user.id, user.username || 'anonymous');
      
      if (startParam && startParam !== user.id.toString()) {
        await addReferral(parseInt(startParam), user.id);
        await updateUserPoints(parseInt(startParam), 50);
        
        // Notify referrer
        await bot.sendMessage(parseInt(startParam), 
          `${EMOJIS.SUCCESS} You earned 50 points from a new referral!`
        );
      }
      
      const welcomeMessage = `
${EMOJIS.WELCOME} *Welcome to BRZY Points Bot!*

${EMOJIS.BONUS} You've received 1000 points as a welcome bonus!

🚀 *What you can do:*
• Earn points through tasks
• Refer friends for 50 points each
• Track your progress
• Complete challenges

Select an option below:`;

      await bot.sendMessage(chatId, welcomeMessage, {
        parse_mode: 'Markdown',
        ...getMainMenuKeyboard()
      });
    } else {
      const welcomeBackMessage = `
${EMOJIS.WELCOME} *Welcome back!*

Current Points: ${dbUser.points}
Total Referrals: ${dbUser.referralCount}

What would you like to do?`;

      await bot.sendMessage(chatId, welcomeBackMessage, {
        parse_mode: 'Markdown',
        ...getMainMenuKeyboard()
      });
    }
  } catch (error) {
    console.error('Error in handleStart:', error);
    await bot.sendMessage(chatId, 'An error occurred. Please try again later.');
  }
};

export const handlePoints = async (bot, msg) => {
  const chatId = msg.chat.id;
  try {
    const user = await getUser(msg.chat.id);
    if (!user) {
      await bot.sendMessage(chatId, 'Please start the bot first using /start');
      return;
    }
    
    const pointsMessage = `
${EMOJIS.POINTS} *Your Points Balance*

Current Points: ${user.points}
Total Referrals: ${user.referralCount}
Points from Referrals: ${user.referralCount * 50}
`;

    await bot.sendMessage(chatId, pointsMessage, {
      parse_mode: 'Markdown',
      ...getMainMenuKeyboard()
    });
  } catch (error) {
    console.error('Error in handlePoints:', error);
    await bot.sendMessage(chatId, 'An error occurred. Please try again later.');
  }
};

export const handleReferral = async (bot, msg) => {
  const chatId = msg.chat.id;
  try {
    const user = await getUser(msg.chat.id);
    if (!user) {
      await bot.sendMessage(chatId, 'Please start the bot first using /start');
      return;
    }
    
    const botUsername = (await bot.getMe()).username;
    const referralLink = `https://t.me/${botUsername}?start=${user.userId}`;
    const referrals = await getReferrals(user.userId);
    
    const referralMessage = `
${EMOJIS.REFERRAL} *Your Referral Link*

Share this link to earn 50 points per referral!

${referralLink}

*Statistics:*
• Total Referrals: ${user.referralCount}
• Points Earned: ${user.referralCount * 50}
• Active Referrals: ${referrals.length}
`;

    await bot.sendMessage(chatId, referralMessage, {
      parse_mode: 'Markdown',
      ...getMainMenuKeyboard()
    });
  } catch (error) {
    console.error('Error in handleReferral:', error);
    await bot.sendMessage(chatId, 'An error occurred. Please try again later.');
  }
};

export const handleTasks = async (bot, msg) => {
  const chatId = msg.chat.id;
  try {
    const tasksMessage = `
${EMOJIS.TASKS} *Available Tasks*

Complete these tasks to earn points:

1. Follow Twitter (100 points)
2. Join Telegram Group (100 points)
3. Share a post (100 points)
4. Complete verification (100 points)

Click the buttons below to start:`;

    const taskKeyboard = {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🐦 Follow Twitter', url: 'https://twitter.com/BRZYcoin' },
            { text: '💬 Join Telegram', url: 'https://t.me/BRZYcoin' }
          ],
          [
            { text: '✅ Verify Tasks', callback_data: 'verify_tasks' },
            { text: '↩️ Back to Menu', callback_data: 'start' }
          ]
        ]
      }
    };

    await bot.sendMessage(chatId, tasksMessage, {
      parse_mode: 'Markdown',
      ...taskKeyboard
    });
  } catch (error) {
    console.error('Error in handleTasks:', error);
    await bot.sendMessage(chatId, 'An error occurred. Please try again later.');
  }
};

export const handleStats = async (bot, msg) => {
  const chatId = msg.chat.id;
  try {
    const user = await getUser(msg.chat.id);
    if (!user) {
      await bot.sendMessage(chatId, 'Please start the bot first using /start');
      return;
    }
    
    const referrals = await getReferrals(user.userId);
    
    const statsMessage = `
${EMOJIS.CHART} *Your Statistics*

Points Balance: ${user.points}
Total Referrals: ${user.referralCount}
Points from Referrals: ${user.referralCount * 50}
Tasks Completed: ${referrals.length}

Keep earning points by:
• Completing tasks
• Referring friends
• Participating in events
`;

    await bot.sendMessage(chatId, statsMessage, {
      parse_mode: 'Markdown',
      ...getMainMenuKeyboard()
    });
  } catch (error) {
    console.error('Error in handleStats:', error);
    await bot.sendMessage(chatId, 'An error occurred. Please try again later.');
  }
};

export const handleTaskVerification = async (bot, msg) => {
  const chatId = msg.chat.id;
  try {
    const user = await getUser(msg.chat.id);
    if (!user) {
      await bot.sendMessage(chatId, 'Please start the bot first using /start');
      return;
    }

    await bot.sendMessage(chatId, `${EMOJIS.TASKS} Verifying your tasks...`);
    const result = await completeTask(user.userId, 'twitter_follow');
    
    if (result) {
      await bot.sendMessage(chatId, 
        `${EMOJIS.SUCCESS} Task completed! You earned 100 points!`,
        { ...getMainMenuKeyboard() }
      );
    } else {
      await bot.sendMessage(chatId, 
        'You have already completed this task.',
        { ...getMainMenuKeyboard() }
      );
    }
  } catch (error) {
    console.error('Error in handleTaskVerification:', error);
    await bot.sendMessage(chatId, 'An error occurred. Please try again later.');
  }
};