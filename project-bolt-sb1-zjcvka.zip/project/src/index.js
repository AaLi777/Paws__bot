import TelegramBot from 'node-telegram-bot-api';
import dotenv from 'dotenv';
import { initDB } from './database/db.js';
import { handleStart, handlePoints, handleReferral, handleTasks, handleStats } from './handlers/commands.js';

dotenv.config();

const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) {
  console.error('TELEGRAM_BOT_TOKEN is required in .env file');
  process.exit(1);
}

const bot = new TelegramBot(token, { polling: true });

// Initialize database
(async () => {
  await initDB();
  console.log('Bot system initialized');

  // Handle /start command with referral parameter
  bot.onText(/\/start(?:\s+(\w+))?/, async (msg, match) => {
    const startParam = match[1]; // This will contain the referral ID if present
    await handleStart(bot, msg, startParam);
  });

  // Handle button callbacks
  bot.on('callback_query', async (callbackQuery) => {
    const action = callbackQuery.data;
    const msg = callbackQuery.message;

    switch (action) {
      case 'points':
        await handlePoints(bot, msg);
        break;
      case 'referral':
        await handleReferral(bot, msg);
        break;
      case 'tasks':
        await handleTasks(bot, msg);
        break;
      case 'stats':
        await handleStats(bot, msg);
        break;
      case 'verify_tasks':
        // Handle task verification
        await handleTaskVerification(bot, msg);
        break;
    }

    // Answer callback query
    await bot.answerCallbackQuery(callbackQuery.id);
  });

  console.log('Bot is running...');
})();